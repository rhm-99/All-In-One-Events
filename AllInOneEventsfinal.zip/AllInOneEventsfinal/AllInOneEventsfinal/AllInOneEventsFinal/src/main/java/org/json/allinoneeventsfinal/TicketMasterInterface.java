/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.json.allinoneeventsfinal;

import java.util.List;
import org.json.allinoneeventsfinal.TicketMaster;

/**
 *
 * @author rhiya
 */
public interface TicketMasterInterface {

    List<Event> findAllEvents();
}

